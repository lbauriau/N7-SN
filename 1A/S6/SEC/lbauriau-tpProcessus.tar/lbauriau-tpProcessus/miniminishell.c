#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <wait.h>
#include <stdbool.h>

int main(){

    char * buf = malloc(50); /* contient la comande saisie au clavier*/
    int ret; /* valeur de retour de scanf*/
    int pid, codeTerm, res;

    printf(">>>");
    ret = scanf("%s", buf); /* lit et range dans buf la chaine entrée au clavier*/

    while (ret ==1 && strcmp(buf,"exit")) {
    
        char aux[35] = "/bin/";
        pid = fork();

        if (pid == -1) {
            printf("Erreur fork\n");
            exit(1);
        }

        if (pid == 0) {		/* fils */
            strcat(aux,buf);
            res = execl (aux,buf,NULL);
            printf("ECHEC\n");
            exit(res);
        } else {		/* père */
            pid = wait(&codeTerm);
            if (codeTerm ==0){
                printf("SUCCESS\n");
            }
        }

        printf(">>>");
        ret = scanf("%s", buf); /* lit et range dans buf la chaine entrée au clavier*/
    }

    if (!strcmp(buf,"exit")) {
        printf("Salut\n");
    } else {
        printf("\nSalut\n");
    }

    return EXIT_SUCCESS;

}
