#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <signal.h>   /* traitement des signaux */


void handler(int signal_num) {
    printf("Reception %d\n", signal_num);
    }



int main(){

    struct sigaction sig;
    int valeur_sig;

    /*Initialisation du sigaction*/
    sig.sa_flags = 0;
    sig.sa_handler = handler;

    /*Association des signaux au traitant*/
    valeur_sig = sigaction(SIGUSR1, &sig, NULL);
    /*Vérification du signal*/
    if(valeur_sig<0){
        perror("sigaction failed");
        exit(1);
    }


    valeur_sig = sigaction(SIGUSR2, &sig, NULL);

    /*Masquage*/
    sigset_t ens_masque ; 
    sigemptyset(&ens_masque); 
    sigaddset(&ens_masque, SIGINT);
    sigaddset(&ens_masque, SIGUSR1);
    sigprocmask(SIG_SETMASK, &ens_masque, NULL);

    /*Sommeil*/
    sleep(10);

    /*Envoie d'un signal*/
    kill(getpid(), SIGUSR1);
    kill(getpid(), SIGUSR1);

    sleep(5);

    kill(getpid(), SIGUSR2);
    kill(getpid(), SIGUSR2);

    /*démasquer SIGUSR1 et masquer SIGINT*/
    sigemptyset(&ens_masque); 
    sigaddset(&ens_masque, SIGINT);
    sigprocmask(SIG_SETMASK, &ens_masque, NULL);

    sleep(10);

    sigemptyset(&ens_masque);
    sigprocmask(SIG_SETMASK, &ens_masque, NULL);

    printf("Salut");

    return EXIT_SUCCESS;

}