#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */ 
#include <sys/wait.h> /* wait */
#include <sys/types.h>
#include <string.h>   /* opérations sur les chaines */
#include <fcntl.h>   

int main(int argc,char *argv[]) {

    if (argc != 2){
        printf("Erreur, vous devez fournir 2 arguments\n");
        perror("");
        exit(1) ;
    }

    int p1[2], p2[2];

    /*Création du premier pipe*/
    int p1_error = pipe(p1);
    /*Vérification du pipe1*/
    if(p1_error<0){
        printf("Erreur dans la création du premier pipe");
        exit(2);
    }

    /*Création du second pipe*/
    int p2_error = pipe(p2);
    /*Vérification du pipe2*/
    if(p2_error<0){
        printf("Erreur dans la création du second pipe");
        exit(2);
    }

    int pidfils1 = fork();
    if (pidfils1 == -1) {
        printf("Erreur dans le premier fork\n");
        exit(4);
    }
    
    if (pidfils1 == 0){ /*FILS 1 */
        close(p1[0]);
        close(p2[1]);
        close(p2[0]);

        int dup1_error = dup2(p1[1],1);
        if (dup1_error<0){
            printf("Erreur, dans le dup2 du premier fils.\n") ;
            exit(5);
        }
        execlp("who","who", NULL, NULL);
        
        close (p1[1]);

    } else { /*PERE*/

        /*Deuxième fils*/
        int pidfils2 = fork();
        if (pidfils2 == -1) {
            printf("Erreur fork dans le second fork\n");
            exit(5);
        }

        if (pidfils2 == 0){ /*FILS 2*/
            close(p1[1]);
            close(p2[0]);

            int dup2_error = dup2(p1[0],0);
            if (dup2_error<0){
                printf("Erreur, dans le dup2 du second fils pour la lecture.\n") ;
                exit(6);
            }
            int dup22_error = dup2(p2[1],1);
            if (dup22_error<0){
                printf("Erreur, dans le dup2 du second fils pour l'écriture.\n") ;
                exit(7);
            }

            execlp("grep","grep", argv[1], NULL);

            close (p2[1]);
            close (p1[0]);
            
        } else { /*PERE*/
            close(p1[0]);
            close(p1[1]);
            close(p2[1]);

            int dup3_error = dup2(p2[0],0);
            if (dup3_error<0){
                printf("Erreur, dans le dup2 du père.\n") ;
                exit(8);
            }

            execlp("wc","wc", "-l", NULL);
        
            close (p2[0]);
        }
    }


}