#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */ 
#include <sys/wait.h> /* wait */
#include <sys/types.h>
#include <string.h>   /* opérations sur les chaines */
#include <fcntl.h>   

#define BUFSIZE 32  /*Taille du buffer*/
#define REPETITION 10 /*Nombre de fois où l'on afficher PERE*/
#define ATTENTE 1 /*Durée de sommeil*/

int main() {
  
    int desc_dic, desc_dic2;
    int lecture;

    int pidfils1, pidfils2;
    int taille_ecriture;


    /*Traitement du premier fils*/
    pidfils1 = fork();
    if (pidfils1 == -1) {
        printf("Erreur fork\n");
        exit(1);
    }
        
    if (pidfils1 == 0){ /*FILS 1 */
        /*Ouverture du nouveau fichier*/
        desc_dic = open("temp",  O_WRONLY | O_CREAT | O_TRUNC, 0777);
        /*Traitement d'un problème à la création d'un nouveau fichier*/
        if (desc_dic < 0) {
            printf("Erreur en ouvrant le nouveau fichier %d\n", desc_dic) ;
            exit(2) ;
        }
        for (int i = 1; i<=30; i++){
            sleep(ATTENTE);
            taille_ecriture = write(desc_dic,&i,sizeof(int));
            if (i%10 ==0){
                lseek(desc_dic, 0, SEEK_SET);
            }
        }
        close(desc_dic);

    } else { /*PERE*/

        /*Deuxième fils*/
        pidfils2 = fork();
        if (pidfils2 == -1) {
            printf("Erreur fork\n");
            exit(3);
        }

        /*Ouverture du nouveau fichier*/
        desc_dic2 = open("temp",  O_RDONLY, 0777);
        /*Traitement d'un problème à la création d'un nouveau fichier*/
        if (desc_dic2 < 0) {
            printf("Erreur en ouvrant le nouveau fichier %d\n", desc_dic2) ;
            exit(4) ;
        }
    
        if (pidfils2 == 0){ /*FILS*/
            for (int i = 1; i<REPETITION ; i++){
                taille_ecriture = read(desc_dic2,&lecture, sizeof(int));
                while (taille_ecriture > 0) {
                    printf("%d\n", lecture);
                    taille_ecriture = read(desc_dic2,&lecture, sizeof(int));
                }
                lseek(desc_dic2, 0, SEEK_SET);
                printf("\n");
                sleep(ATTENTE*5);
            }
            close(desc_dic2);

        } else { /*PERE*/
            waitpid(pidfils2,0,0);
            printf("\nProcessus Principal termine\n");
        }
    }
    

    return EXIT_SUCCESS ;

}