#include <stdio.h>    /* entrées sorties */
#include <unistd.h>   /* pimitives de base : fork, ...*/
#include <stdlib.h>   /* exit */ 
#include <sys/wait.h> /* wait */
#include <sys/types.h>
#include <string.h>   /* opérations sur les chaines */
#include <fcntl.h>   

#define BUFSIZE 32  /*Taille du buffer*/

int main(int argc,char *argv[]) {
  
    if (argc != 3){
        printf("Erreur, vous devez fournir 2 arguments\n") ;
        exit(5) ;
    }

    int desc_fic, desc_copie, taille, taille_copie;

    char* buffer = malloc(BUFSIZE);


    //bzero(buffer, sizeof(buffer));


    /* ouverture du fichier en lecture */
    desc_fic = open(argv[1], O_RDONLY) ;
    /*Traitement d'un problème à l'ouverture du fichier*/
    if (desc_fic < 0) {
        printf("Erreur ouverture %s\n", argv[0]) ;
        exit(1) ;
    }


    /* création du nouveau fichier */
    desc_copie = open(argv[2], O_CREAT | O_TRUNC | O_WRONLY, S_IRWXU);
    /*Traitement d'un problème à la création d'un nouveau fichier*/
    if (desc_copie < 0) {
        printf("Erreur à la création de la copie %s\n", argv[1]) ;
        exit(2) ;
        perror("");
    }

    /*Initialisation de la taille avec le fichier à lire*/
    taille = read (desc_fic, buffer, BUFSIZE);
    if (taille < 0) {
        printf("Erreur de taille dans le fichier à lire") ;
        exit(3) ;
    }

    while (taille>0){
        taille_copie = write(desc_copie, buffer, taille);
        if (taille_copie < 0) {
            printf("Erreur de taille dans le fichier à écrire") ;
            exit(4) ;
        }

        taille = read (desc_fic, buffer, BUFSIZE);
        if (taille < 0) {
            printf("Erreur de taille dans le fichier à lire") ;
            exit(3) ;
        }
    }


    close(desc_fic) ;
    close(desc_copie) ;
    printf("\nProcessus Principal termine\n") ;
    return EXIT_SUCCESS ;

}